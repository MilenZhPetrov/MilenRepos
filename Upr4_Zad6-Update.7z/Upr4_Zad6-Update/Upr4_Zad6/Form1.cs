﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Upr4_Zad6
{
    public partial class Form1 : Form
    {
        // Size
        string size;
        double size_price = 0;
        // Crust
        string crust;
        // Cheese
        string cheese = " with extra cheese ";
        double cheese_price = 1.50;
        // Topping
        string toppings;
        int topp_num;
        double topping_price = 1.00;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Toppings_CLB_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            // Calcs topping number
             topp_num = Toppings_CLB.CheckedItems.Count;
            if (e.NewValue == CheckState.Checked)
                topp_num++;
            else if (e.NewValue == CheckState.Unchecked)
                topp_num--;
            
            // Adds the names of chosen toppings
            var checkedListBox = (CheckedListBox)sender;
            toppings += Toppings_CLB.Items[e.Index].ToString() + ", ";
        }

        private void Calc_Button_Click(object sender, EventArgs e)
        {
            double total_price = 0;
            string total = "You ordered a ";
            
            // Gets size
            if (Small_RB.Checked)
            { size_price = 9.25; size = " small "; }
            if (Medium_RB.Checked)
            { size_price = 11.50; size = " medium "; }
            if (Large_RB.Checked)
            { size_price = 13.75; size = " large "; }
            total += size;

            // Gets crust
            if(Thin_RB.Checked)  crust = " thin ";
            if(Thick_RB.Checked)  crust = " thick ";
            total += crust + " pizza";

            // Checks cheese
            if (Cheese_CB.Checked)
            { total += cheese; total_price += cheese_price; }

            // Gets toppings
            if (topp_num > 0)
                total += " and " + topp_num + " topping(s): "+toppings;

            // Calcs total price
            total_price += size_price + topp_num*topping_price;
            total += "\nYour total is: "+total_price + " dollars.";

            // Sets message
            Total_TB.Text = total;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Loads topping list in list box
            string[] toppings = System.IO.File.ReadAllLines("C:\\Users\\student\\Desktop\\MilenRepos-master\\MilenRepos-master\\Upr4\\Upr4\\Upr4_Zad6\\Upr4_Zad6\\Toppings.txt");
            foreach (string a in toppings)
            {
                Toppings_CLB.Items.Add(a);
            }
        }
    }
}
