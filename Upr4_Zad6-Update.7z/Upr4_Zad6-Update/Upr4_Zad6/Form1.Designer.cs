﻿namespace Upr4_Zad6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Size_GB = new System.Windows.Forms.GroupBox();
            this.Large_RB = new System.Windows.Forms.RadioButton();
            this.Medium_RB = new System.Windows.Forms.RadioButton();
            this.Small_RB = new System.Windows.Forms.RadioButton();
            this.Crust_GB = new System.Windows.Forms.GroupBox();
            this.Thick_RB = new System.Windows.Forms.RadioButton();
            this.Thin_RB = new System.Windows.Forms.RadioButton();
            this.Cheese_CB = new System.Windows.Forms.CheckBox();
            this.Toppings_CLB = new System.Windows.Forms.CheckedListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Calc_Button = new System.Windows.Forms.Button();
            this.Total_TB = new System.Windows.Forms.RichTextBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.Size_GB.SuspendLayout();
            this.Crust_GB.SuspendLayout();
            this.SuspendLayout();
            // 
            // Size_GB
            // 
            this.Size_GB.Controls.Add(this.Large_RB);
            this.Size_GB.Controls.Add(this.Medium_RB);
            this.Size_GB.Controls.Add(this.Small_RB);
            this.Size_GB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Size_GB.ForeColor = System.Drawing.Color.Blue;
            this.Size_GB.Location = new System.Drawing.Point(12, 12);
            this.Size_GB.Name = "Size_GB";
            this.Size_GB.Size = new System.Drawing.Size(105, 86);
            this.Size_GB.TabIndex = 0;
            this.Size_GB.TabStop = false;
            this.Size_GB.Text = "Size:";
            // 
            // Large_RB
            // 
            this.Large_RB.AutoSize = true;
            this.Large_RB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Large_RB.Location = new System.Drawing.Point(6, 65);
            this.Large_RB.Name = "Large_RB";
            this.Large_RB.Size = new System.Drawing.Size(88, 17);
            this.Large_RB.TabIndex = 3;
            this.Large_RB.Text = "Large - 13.75";
            this.Large_RB.UseVisualStyleBackColor = true;
            // 
            // Medium_RB
            // 
            this.Medium_RB.AutoSize = true;
            this.Medium_RB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Medium_RB.Location = new System.Drawing.Point(6, 42);
            this.Medium_RB.Name = "Medium_RB";
            this.Medium_RB.Size = new System.Drawing.Size(98, 17);
            this.Medium_RB.TabIndex = 2;
            this.Medium_RB.Text = "Medium - 11.50";
            this.Medium_RB.UseVisualStyleBackColor = true;
            // 
            // Small_RB
            // 
            this.Small_RB.AutoSize = true;
            this.Small_RB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Small_RB.Location = new System.Drawing.Point(6, 19);
            this.Small_RB.Name = "Small_RB";
            this.Small_RB.Size = new System.Drawing.Size(80, 17);
            this.Small_RB.TabIndex = 1;
            this.Small_RB.Text = "Small - 9.25";
            this.Small_RB.UseVisualStyleBackColor = true;
            // 
            // Crust_GB
            // 
            this.Crust_GB.Controls.Add(this.Thick_RB);
            this.Crust_GB.Controls.Add(this.Thin_RB);
            this.Crust_GB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Crust_GB.ForeColor = System.Drawing.Color.Blue;
            this.Crust_GB.Location = new System.Drawing.Point(12, 104);
            this.Crust_GB.Name = "Crust_GB";
            this.Crust_GB.Size = new System.Drawing.Size(104, 65);
            this.Crust_GB.TabIndex = 1;
            this.Crust_GB.TabStop = false;
            this.Crust_GB.Text = "Crust:";
            // 
            // Thick_RB
            // 
            this.Thick_RB.AutoSize = true;
            this.Thick_RB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Thick_RB.Location = new System.Drawing.Point(6, 42);
            this.Thick_RB.Name = "Thick_RB";
            this.Thick_RB.Size = new System.Drawing.Size(52, 17);
            this.Thick_RB.TabIndex = 1;
            this.Thick_RB.Text = "Thick";
            this.Thick_RB.UseVisualStyleBackColor = true;
            // 
            // Thin_RB
            // 
            this.Thin_RB.AutoSize = true;
            this.Thin_RB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Thin_RB.Location = new System.Drawing.Point(6, 19);
            this.Thin_RB.Name = "Thin_RB";
            this.Thin_RB.Size = new System.Drawing.Size(46, 17);
            this.Thin_RB.TabIndex = 0;
            this.Thin_RB.Text = "Thin";
            this.Thin_RB.UseVisualStyleBackColor = true;
            // 
            // Cheese_CB
            // 
            this.Cheese_CB.AutoSize = true;
            this.Cheese_CB.ForeColor = System.Drawing.Color.Blue;
            this.Cheese_CB.Location = new System.Drawing.Point(12, 175);
            this.Cheese_CB.Name = "Cheese_CB";
            this.Cheese_CB.Size = new System.Drawing.Size(119, 17);
            this.Cheese_CB.TabIndex = 2;
            this.Cheese_CB.Text = "Extra Cheese - 1.50";
            this.Cheese_CB.UseVisualStyleBackColor = true;
            // 
            // Toppings_CLB
            // 
            this.Toppings_CLB.FormattingEnabled = true;
            this.Toppings_CLB.Location = new System.Drawing.Point(152, 30);
            this.Toppings_CLB.Name = "Toppings_CLB";
            this.Toppings_CLB.Size = new System.Drawing.Size(120, 124);
            this.Toppings_CLB.TabIndex = 3;
            this.Toppings_CLB.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.Toppings_CLB_ItemCheck);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(149, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Toppings - 1$ each";
            // 
            // Calc_Button
            // 
            this.Calc_Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Calc_Button.ForeColor = System.Drawing.Color.Blue;
            this.Calc_Button.Location = new System.Drawing.Point(176, 171);
            this.Calc_Button.Name = "Calc_Button";
            this.Calc_Button.Size = new System.Drawing.Size(75, 23);
            this.Calc_Button.TabIndex = 5;
            this.Calc_Button.Text = "Calculate";
            this.Calc_Button.UseVisualStyleBackColor = true;
            this.Calc_Button.Click += new System.EventHandler(this.Calc_Button_Click);
            // 
            // Total_TB
            // 
            this.Total_TB.Location = new System.Drawing.Point(12, 200);
            this.Total_TB.Name = "Total_TB";
            this.Total_TB.Size = new System.Drawing.Size(260, 52);
            this.Total_TB.TabIndex = 6;
            this.Total_TB.Text = "";
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 264);
            this.Controls.Add(this.Total_TB);
            this.Controls.Add(this.Calc_Button);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Toppings_CLB);
            this.Controls.Add(this.Cheese_CB);
            this.Controls.Add(this.Crust_GB);
            this.Controls.Add(this.Size_GB);
            this.Name = "Form1";
            this.Text = "Pizza Order";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Size_GB.ResumeLayout(false);
            this.Size_GB.PerformLayout();
            this.Crust_GB.ResumeLayout(false);
            this.Crust_GB.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox Size_GB;
        private System.Windows.Forms.GroupBox Crust_GB;
        private System.Windows.Forms.RadioButton Thick_RB;
        private System.Windows.Forms.RadioButton Thin_RB;
        private System.Windows.Forms.CheckBox Cheese_CB;
        private System.Windows.Forms.CheckedListBox Toppings_CLB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Calc_Button;
        private System.Windows.Forms.RichTextBox Total_TB;
        private System.Windows.Forms.RadioButton Large_RB;
        private System.Windows.Forms.RadioButton Medium_RB;
        private System.Windows.Forms.RadioButton Small_RB;
        private System.Windows.Forms.ImageList imageList1;
    }
}

